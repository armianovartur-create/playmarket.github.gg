<?php
/**
 * Main fallback template file
 * Name: PlayMarket Theme
 */

get_header(); ?>

<main class="main-content" style="background-color: #000000; min-height: 80vh; padding: 60px 20px; color: #ffffff;">
    <div class="container" style="max-width: 1200px; margin: 0 auto; font-family: sans-serif;">
        <?php if ( have_posts() ) : ?>
            <header class="page-header" style="margin-bottom: 40px; border-left: 4px solid #00FF00; padding-left: 15px;">
                <h1 class="page-title" style="font-size: 2.5rem; text-transform: uppercase; tracking: 1px; color: #ffffff;">
                    <?php single_post_title(); ?>
                </h1>
            </header>

            <div class="archive-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 30px;">
                <?php while ( have_posts() ) : the_post(); ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?> style="background: #121212; border: 1px solid #1f1f1f; padding: 25px; border-radius: 8px; transition: border-color 0.3s ease;">
                        <h2 style="font-size: 1.5rem; margin-top: 0;">
                            <a href="<?php the_permalink(); ?>" style="color: #00FF00; text-decoration: none;"><?php the_title(); ?></a>
                        </h2>
                        <div style="color: #aaaaaa; font-size: 0.9rem; margin-bottom: 15px;">
                            <?php echo get_the_date(); ?>
                        </div>
                        <div class="entry-content" style="line-height: 1.6; color: #e0e0e0;">
                            <?php the_excerpt(); ?>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>

            <div class="pagination" style="margin-top: 40px; color: #00FF00;">
                <?php the_posts_pagination(); ?>
            </div>

        <?php else : ?>
            <div class="no-content" style="text-align: center; padding: 100px 0;">
                <h2 style="color: #39FF14;">Контент не найден</h2>
                <p style="color: #888;">Похоже, здесь пока ничего нет.</p>
            </div>
        <?php endif; ?>
    </div>
</main>

<?php get_footer(); ?>