<?php
/**
 * Front Page Template
 *
 * @package PlayMarket
 * @since 1.0.0
 */

get_header();
?>

<section class="pm-hero">
    <div class="pm-hero-bg"></div>
    <div class="pm-container">
        <div class="pm-hero-content">
            <span class="pm-hero-badge pm-animate-once pm-fade-in-up" data-i18n="hero.badge"><?php esc_html_e( 'Trusted Gaming Marketplace', 'playmarket' ); ?></span>
            <h1 class="pm-hero-title pm-animate-once pm-fade-in-up pm-delay-1">
                <span data-i18n="hero.title"><?php esc_html_e( 'Trade Game Accounts & Currency', 'playmarket' ); ?></span>
                <span class="pm-text-neon" data-i18n="hero.title_accent"><?php esc_html_e( '100% Secured', 'playmarket' ); ?></span>
            </h1>
            <p class="pm-hero-subtitle pm-animate-once pm-fade-in-up pm-delay-2" data-i18n="hero.subtitle">
                <?php esc_html_e( 'Buy and sell with confidence. Every transaction is protected by our Escrow security system — funds are frozen until you confirm delivery.', 'playmarket' ); ?>
            </p>
            <div class="pm-hero-actions">
                <a href="#" class="pm-btn pm-btn-primary pm-btn-lg" data-i18n="hero.browse_btn"><?php esc_html_e( 'Browse Listings', 'playmarket' ); ?></a>
                <a href="#" class="pm-btn pm-btn-secondary pm-btn-lg" data-i18n="hero.sell_btn"><?php esc_html_e( 'Start Selling', 'playmarket' ); ?></a>
            </div>
            <div class="pm-hero-stats">
                <div class="pm-hero-stat">
                    <span class="pm-hero-stat-number">12,458+</span>
                    <span class="pm-hero-stat-label" data-i18n="hero.stat_deals"><?php esc_html_e( 'Completed Deals', 'playmarket' ); ?></span>
                </div>
                <div class="pm-hero-stat-divider"></div>
                <div class="pm-hero-stat">
                    <span class="pm-hero-stat-number">99.2%</span>
                    <span class="pm-hero-stat-label" data-i18n="hero.stat_success"><?php esc_html_e( 'Success Rate', 'playmarket' ); ?></span>
                </div>
                <div class="pm-hero-stat-divider"></div>
                <div class="pm-hero-stat">
                    <span class="pm-hero-stat-number">2,340+</span>
                    <span class="pm-hero-stat-label" data-i18n="hero.stat_sellers"><?php esc_html_e( 'Active Sellers', 'playmarket' ); ?></span>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="pm-section pm-features">
    <div class="pm-container">
        <div class="pm-section-header">
            <span class="pm-section-tag" data-i18n="features.tag"><?php esc_html_e( 'Why PlayMarket', 'playmarket' ); ?></span>
            <h2 class="pm-section-title" data-i18n="features.title">
                <?php esc_html_e( 'Built for Safe, Fast Trading', 'playmarket' ); ?>
            </h2>
            <p class="pm-section-desc" data-i18n="features.desc">
                <?php esc_html_e( 'We eliminate risk in P2P gaming transactions with bank-grade security and automated arbitration.', 'playmarket' ); ?>
            </p>
        </div>
        <div class="pm-grid pm-grid-3">
            <div class="pm-feature-card pm-animate-once pm-fade-in-up pm-delay-1">
                <div class="pm-feature-icon pm-feature-icon-shield">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                </div>
                <h3 class="pm-feature-title" data-i18n="features.escrow_title"><?php esc_html_e( 'Escrow Protection', 'playmarket' ); ?></h3>
                <p class="pm-feature-text" data-i18n="features.escrow_text"><?php esc_html_e( 'Funds are locked in our secure escrow account the moment you pay. The seller gets nothing until you confirm everything is correct.', 'playmarket' ); ?></p>
            </div>
            <div class="pm-feature-card pm-animate-once pm-fade-in-up pm-delay-2">
                <div class="pm-feature-icon pm-feature-icon-clock">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                </div>
                <h3 class="pm-feature-title" data-i18n="features.clock_title"><?php esc_html_e( '3-Hour Dispute Rule', 'playmarket' ); ?></h3>
                <p class="pm-feature-text" data-i18n="features.clock_text"><?php esc_html_e( 'If a party goes offline for more than 3 hours during an active deal, our arbitration matrix automatically rules in favor of the responsive party.', 'playmarket' ); ?></p>
            </div>
            <div class="pm-feature-card pm-animate-once pm-fade-in-up pm-delay-3">
                <div class="pm-feature-icon pm-feature-icon-handshake">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                </div>
                <h3 class="pm-feature-title" data-i18n="features.p2p_title"><?php esc_html_e( 'Secure P2P Transactions', 'playmarket' ); ?></h3>
                <p class="pm-feature-text" data-i18n="features.p2p_text"><?php esc_html_e( 'Direct buyer-to-seller trading with full transparency. Chat, verify, and trade without intermediaries — backed by our guarantee.', 'playmarket' ); ?></p>
            </div>
        </div>
    </div>
</section>

<section class="pm-section pm-escrow-section">
    <div class="pm-container">
        <div class="pm-section-header">
            <span class="pm-section-tag" data-i18n="escrow.tag"><?php esc_html_e( 'How It Works', 'playmarket' ); ?></span>
            <h2 class="pm-section-title" data-i18n="escrow.title">
                <?php esc_html_e( 'Escrow Security System', 'playmarket' ); ?>
            </h2>
            <p class="pm-section-desc" data-i18n="escrow.desc">
                <?php esc_html_e( 'Your money is never released until you confirm you have received exactly what you paid for.', 'playmarket' ); ?>
            </p>
        </div>
        <div class="pm-escrow-flow">
            <div class="pm-escrow-step pm-animate-once pm-fade-in-up pm-delay-1">
                <div class="pm-escrow-step-number">1</div>
                <div class="pm-escrow-step-content">
                    <h3 data-i18n="escrow.step1_title"><?php esc_html_e( 'Buyer Pays → Escrow Holds', 'playmarket' ); ?></h3>
                    <p data-i18n="escrow.step1_text"><?php esc_html_e( 'You send payment to the marketplace. Funds are frozen in our secure escrow account — the seller cannot access them.', 'playmarket' ); ?></p>
                </div>
                <div class="pm-escrow-step-arrow">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                </div>
            </div>
            <div class="pm-escrow-step pm-animate-once pm-fade-in-up pm-delay-2">
                <div class="pm-escrow-step-number">2</div>
                <div class="pm-escrow-step-content">
                    <h3 data-i18n="escrow.step2_title"><?php esc_html_e( 'Seller Delivers → Buyer Verifies', 'playmarket' ); ?></h3>
                    <p data-i18n="escrow.step2_text"><?php esc_html_e( 'The seller provides the account, currency, or service. You have a verification window to inspect and confirm everything matches the listing.', 'playmarket' ); ?></p>
                </div>
                <div class="pm-escrow-step-arrow">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                </div>
            </div>
            <div class="pm-escrow-step pm-animate-once pm-fade-in-up pm-delay-3">
                <div class="pm-escrow-step-number">3</div>
                <div class="pm-escrow-step-content">
                    <h3 data-i18n="escrow.step3_title"><?php esc_html_e( 'Buyer Confirms → Seller Gets Paid', 'playmarket' ); ?></h3>
                    <p data-i18n="escrow.step3_text"><?php esc_html_e( 'Happy with the delivery? Click confirm. Funds are instantly released from escrow to the seller. Secure, fast, and fair.', 'playmarket' ); ?></p>
                </div>
            </div>
        </div>
        <div class="pm-escrow-note">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            <span data-i18n="escrow.note"><?php esc_html_e( 'If anything goes wrong, funds stay frozen until the dispute is resolved. You are always protected.', 'playmarket' ); ?></span>
        </div>
    </div>
</section>

<section class="pm-section pm-dispute-section">
    <div class="pm-container">
        <div class="pm-dispute-layout">
            <div class="pm-dispute-info">
                <span class="pm-section-tag" data-i18n="dispute.tag"><?php esc_html_e( 'Fair Arbitration', 'playmarket' ); ?></span>
                <h2 class="pm-section-title" data-i18n="dispute.title">
                    <?php esc_html_e( 'The 3-Hour Dispute Rule', 'playmarket' ); ?>
                </h2>
                <p class="pm-section-desc" data-i18n="dispute.desc">
                    <?php esc_html_e( 'Trading should never stall. Our automated arbitration matrix ensures every dispute is resolved quickly and fairly.', 'playmarket' ); ?>
                </p>
                <div class="pm-dispute-rule">
                    <div class="pm-dispute-rule-header">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                        <span data-i18n="dispute.rule_header"><?php esc_html_e( 'The Clock Starts Ticking', 'playmarket' ); ?></span>
                    </div>
                    <p data-i18n="dispute.rule_text"><?php esc_html_e( 'Once a dispute is opened, both parties have 3 hours to respond and provide evidence. The countdown is visible to everyone involved.', 'playmarket' ); ?></p>
                </div>
                <div class="pm-dispute-matrix">
                    <h3 data-i18n="dispute.matrix_title"><?php esc_html_e( 'Arbitration Matrix', 'playmarket' ); ?></h3>
                    <div class="pm-matrix-grid">
                        <div class="pm-matrix-item pm-matrix-win">
                            <div class="pm-matrix-status">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            </div>
                            <div class="pm-matrix-text">
                                <strong data-i18n="dispute.buyer_wins"><?php esc_html_e( 'Buyer Wins', 'playmarket' ); ?></strong>
                                <span data-i18n="dispute.buyer_wins_text"><?php esc_html_e( 'Full refund if seller is unresponsive or fails to deliver as described.', 'playmarket' ); ?></span>
                            </div>
                        </div>
                        <div class="pm-matrix-item pm-matrix-win">
                            <div class="pm-matrix-status">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            </div>
                            <div class="pm-matrix-text">
                                <strong data-i18n="dispute.seller_wins"><?php esc_html_e( 'Seller Wins', 'playmarket' ); ?></strong>
                                <span data-i18n="dispute.seller_wins_text"><?php esc_html_e( 'Payment released if buyer is unresponsive after verified delivery.', 'playmarket' ); ?></span>
                            </div>
                        </div>
                        <div class="pm-matrix-item pm-matrix-split">
                            <div class="pm-matrix-status">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="4" x2="20" y2="20"/><polyline points="4 20 4 14 10 14"/><polyline points="20 4 20 10 14 10"/></svg>
                            </div>
                            <div class="pm-matrix-text">
                                <strong data-i18n="dispute.split"><?php esc_html_e( 'Split Decision', 'playmarket' ); ?></strong>
                                <span data-i18n="dispute.split_text"><?php esc_html_e( 'Partial refund based on evidence weight when both parties share responsibility.', 'playmarket' ); ?></span>
                            </div>
                        </div>
                        <div class="pm-matrix-item pm-matrix-escalate">
                            <div class="pm-matrix-status">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                            </div>
                            <div class="pm-matrix-text">
                                <strong data-i18n="dispute.manual"><?php esc_html_e( 'Manual Review', 'playmarket' ); ?></strong>
                                <span data-i18n="dispute.manual_text"><?php esc_html_e( 'Complex cases with evidence from both sides are escalated to our moderation team.', 'playmarket' ); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="pm-dispute-visual">
                <div class="pm-timer-card">
                    <div class="pm-timer-card-header">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                        <span data-i18n="dispute.timer_header"><?php esc_html_e( 'Active Dispute Timer', 'playmarket' ); ?></span>
                    </div>
                    <div class="pm-timer-display">
                        <div class="pm-timer-unit">
                            <span class="pm-timer-value">02</span>
                            <span class="pm-timer-unit-label" data-i18n="dispute.timer_hours"><?php esc_html_e( 'Hours', 'playmarket' ); ?></span>
                        </div>
                        <span class="pm-timer-sep">:</span>
                        <div class="pm-timer-unit">
                            <span class="pm-timer-value">47</span>
                            <span class="pm-timer-unit-label" data-i18n="dispute.timer_mins"><?php esc_html_e( 'Mins', 'playmarket' ); ?></span>
                        </div>
                        <span class="pm-timer-sep">:</span>
                        <div class="pm-timer-unit">
                            <span class="pm-timer-value">32</span>
                            <span class="pm-timer-unit-label" data-i18n="dispute.timer_secs"><?php esc_html_e( 'Secs', 'playmarket' ); ?></span>
                        </div>
                    </div>
                    <div class="pm-timer-progress">
                        <div class="pm-timer-progress-bar" style="width: 65%;"></div>
                    </div>
                    <p class="pm-timer-card-note" data-i18n="dispute.timer_note">
                        <?php esc_html_e( 'If the timer reaches zero, the responsive party automatically wins the dispute.', 'playmarket' ); ?>
                    </p>
                </div>
                <div class="pm-dispute-rules-list">
                    <h4 data-i18n="dispute.rules_title"><?php esc_html_e( 'Key Rules', 'playmarket' ); ?></h4>
                    <ul>
                        <li data-i18n="dispute.rule1"><?php esc_html_e( 'Both parties must respond within 3 hours of dispute opening.', 'playmarket' ); ?></li>
                        <li data-i18n="dispute.rule2"><?php esc_html_e( 'Provide screenshots, videos, or chat logs as evidence.', 'playmarket' ); ?></li>
                        <li data-i18n="dispute.rule3"><?php esc_html_e( 'Disputes escalate to manual review if both sides present evidence.', 'playmarket' ); ?></li>
                        <li data-i18n="dispute.rule4"><?php esc_html_e( 'Fraudulent disputes result in permanent account suspension.', 'playmarket' ); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="pm-section pm-cta-section">
    <div class="pm-container">
        <div class="pm-cta-card pm-animate-once pm-scale-in">
            <div class="pm-cta-content">
                <h2 class="pm-cta-title" data-i18n="cta.title"><?php esc_html_e( 'Ready to Trade with Confidence?', 'playmarket' ); ?></h2>
                <p class="pm-cta-text" data-i18n="cta.text"><?php esc_html_e( 'Join thousands of gamers buying and selling securely on PlayMarket. Zero risk, full protection.', 'playmarket' ); ?></p>
                <div class="pm-cta-actions">
                    <a href="#" class="pm-btn pm-btn-primary pm-btn-lg" data-i18n="cta.btn_register"><?php esc_html_e( 'Create Free Account', 'playmarket' ); ?></a>
                    <a href="#" class="pm-btn pm-btn-secondary pm-btn-lg" data-i18n="cta.btn_explore"><?php esc_html_e( 'Explore Listings', 'playmarket' ); ?></a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
get_footer();
