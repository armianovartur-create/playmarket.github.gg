</main>

<footer class="pm-footer">
    <div class="pm-footer-grid">

        <div class="pm-footer-col pm-footer-about">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="pm-logo-link">
                <span class="pm-logo-text">Play<span>Market</span></span>
            </a>
            <p class="pm-footer-desc" data-i18n="footer.desc">
                <?php esc_html_e( 'Modern marketplace for trading game accounts, currency, and P2P services. Secure escrow protection on every deal.', 'playmarket' ); ?>
            </p>
            <?php if ( is_active_sidebar( 'footer-1' ) ) {
                dynamic_sidebar( 'footer-1' );
            } ?>
        </div>

        <div class="pm-footer-col">
            <h4 class="pm-footer-title" data-i18n="footer.marketplace"><?php esc_html_e( 'Marketplace', 'playmarket' ); ?></h4>
            <?php
            if ( has_nav_menu( 'footer' ) ) {
                wp_nav_menu( array(
                    'theme_location' => 'footer',
                    'menu_class'     => 'pm-footer-menu',
                    'container'      => false,
                    'fallback_cb'    => false,
                    'depth'          => 1,
                ) );
            } else {
                ?>
                <ul class="pm-footer-menu">
                    <li><a href="#" data-i18n="footer.browse_listings"><?php esc_html_e( 'Browse Listings', 'playmarket' ); ?></a></li>
                    <li><a href="#" data-i18n="footer.top_sellers"><?php esc_html_e( 'Top Sellers', 'playmarket' ); ?></a></li>
                    <li><a href="#" data-i18n="footer.how_escrow_works"><?php esc_html_e( 'How Escrow Works', 'playmarket' ); ?></a></li>
                    <li><a href="#" data-i18n="footer.dispute_rules"><?php esc_html_e( 'Dispute Rules', 'playmarket' ); ?></a></li>
                </ul>
                <?php
            }
            ?>
            <?php if ( is_active_sidebar( 'footer-2' ) ) {
                dynamic_sidebar( 'footer-2' );
            } ?>
        </div>

        <div class="pm-footer-col">
            <h4 class="pm-footer-title" data-i18n="footer.support"><?php esc_html_e( 'Support', 'playmarket' ); ?></h4>
            <ul class="pm-footer-menu">
                <li><a href="#" data-i18n="footer.help_center"><?php esc_html_e( 'Help Center', 'playmarket' ); ?></a></li>
                <li><a href="#" data-i18n="footer.safety_tips"><?php esc_html_e( 'Safety Tips', 'playmarket' ); ?></a></li>
                <li><a href="#" data-i18n="footer.contact_us"><?php esc_html_e( 'Contact Us', 'playmarket' ); ?></a></li>
                <li><a href="#" data-i18n="footer.report_problem"><?php esc_html_e( 'Report a Problem', 'playmarket' ); ?></a></li>
            </ul>
        </div>

        <div class="pm-footer-col">
            <h4 class="pm-footer-title" data-i18n="footer.legal"><?php esc_html_e( 'Legal', 'playmarket' ); ?></h4>
            <ul class="pm-footer-menu">
                <li><a href="#" data-i18n="footer.terms"><?php esc_html_e( 'Terms of Service', 'playmarket' ); ?></a></li>
                <li><a href="#" data-i18n="footer.privacy"><?php esc_html_e( 'Privacy Policy', 'playmarket' ); ?></a></li>
                <li><a href="#" data-i18n="footer.cookie"><?php esc_html_e( 'Cookie Policy', 'playmarket' ); ?></a></li>
                <li><a href="#" data-i18n="footer.refund"><?php esc_html_e( 'Refund Policy', 'playmarket' ); ?></a></li>
            </ul>
            <?php if ( is_active_sidebar( 'footer-3' ) ) {
                dynamic_sidebar( 'footer-3' );
            } ?>
        </div>

    </div>

    <div class="pm-footer-bottom">
        <span>&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?>
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>.
            <span data-i18n="footer.all_rights"><?php esc_html_e( 'All rights reserved.', 'playmarket' ); ?></span>
        </span>
    </div>
</footer>

</div>

<div class="pm-overlay-hidden" id="pm-mobile-overlay"></div>

<?php wp_footer(); ?>

</body>
</html>
