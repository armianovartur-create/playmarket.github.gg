<?php
/**
 * PlayMarket Theme Functions
 *
 * @package PlayMarket
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'PM_THEME_VERSION', '1.0.0' );
define( 'PM_THEME_DIR', get_template_directory() );
define( 'PM_THEME_URI', get_template_directory_uri() );

/**
 * Theme Setup
 */
function pm_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
    add_theme_support( 'custom-logo', array(
        'height'      => 48,
        'width'       => 180,
        'flex-width'  => true,
        'flex-height' => true,
    ) );
    add_theme_support( 'align-wide' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'woocommerce', array(
        'thumbnail_image_width' => 350,
        'single_image_width'    => 600,
        'product_grid'          => array(
            'default_rows'    => 4,
            'min_rows'        => 2,
            'max_rows'        => 8,
            'default_columns' => 3,
            'min_columns'     => 2,
            'max_columns'     => 4,
        ),
    ) );
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );

    register_nav_menus( array(
        'primary' => __( 'Primary Navigation', 'playmarket' ),
        'footer'  => __( 'Footer Navigation', 'playmarket' ),
    ) );

    load_theme_textdomain( 'playmarket', PM_THEME_DIR . '/languages' );
}
add_action( 'after_setup_theme', 'pm_setup' );

/**
 * Enqueue Scripts and Styles
 */
function pm_enqueue_assets() {
    // Styles
    wp_enqueue_style(
        'playmarket-style',
        PM_THEME_URI . '/style.css',
        array(),
        PM_THEME_VERSION
    );

    // Google Fonts
    wp_enqueue_style(
        'playmarket-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap',
        array(),
        PM_THEME_VERSION
    );

    // Internationalization
    wp_enqueue_script(
        'playmarket-i18n',
        PM_THEME_URI . '/assets/js/i18n.js',
        array(),
        PM_THEME_VERSION,
        array( 'in_footer' => true, 'strategy' => 'defer' )
    );

    // Main JavaScript
    wp_enqueue_script(
        'playmarket-scripts',
        PM_THEME_URI . '/assets/js/theme.js',
        array( 'playmarket-i18n' ),
        PM_THEME_VERSION,
        array( 'in_footer' => true, 'strategy' => 'defer' )
    );

    // Localize script for AJAX
    wp_localize_script( 'playmarket-scripts', 'pmData', array(
        'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'pm_nonce' ),
        'themeUri' => PM_THEME_URI,
        'isRTL'    => is_rtl(),
    ) );

    // Comment reply
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'pm_enqueue_assets' );

/**
 * Register Widget Areas
 */
function pm_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Sidebar', 'playmarket' ),
        'id'            => 'sidebar-main',
        'description'   => __( 'Main sidebar widget area', 'playmarket' ),
        'before_widget' => '<section id="%1$s" class="pm-card pm-widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="pm-card-title">',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          => __( 'Footer Column 1', 'playmarket' ),
        'id'            => 'footer-1',
        'description'   => __( 'Footer first column', 'playmarket' ),
        'before_widget' => '<div id="%1$s" class="pm-footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="pm-footer-title">',
        'after_title'   => '</h4>',
    ) );

    register_sidebar( array(
        'name'          => __( 'Footer Column 2', 'playmarket' ),
        'id'            => 'footer-2',
        'description'   => __( 'Footer second column', 'playmarket' ),
        'before_widget' => '<div id="%1$s" class="pm-footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="pm-footer-title">',
        'after_title'   => '</h4>',
    ) );

    register_sidebar( array(
        'name'          => __( 'Footer Column 3', 'playmarket' ),
        'id'            => 'footer-3',
        'description'   => __( 'Footer third column', 'playmarket' ),
        'before_widget' => '<div id="%1$s" class="pm-footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="pm-footer-title">',
        'after_title'   => '</h4>',
    ) );
}
add_action( 'widgets_init', 'pm_widgets_init' );

/**
 * Custom Body Classes
 */
function pm_body_classes( $classes ) {
    if ( is_singular() ) {
        $classes[] = 'pm-singular';
    }

    if ( is_active_sidebar( 'sidebar-main' ) ) {
        $classes[] = 'pm-has-sidebar';
    }

    if ( class_exists( 'WooCommerce' ) ) {
        if ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) {
            $classes[] = 'pm-woo-page';
        }
    }

    return $classes;
}
add_filter( 'body_class', 'pm_body_classes' );

/**
 * Register Escrow Custom Post Type
 */
function pm_register_escrow_post_type() {
    $labels = array(
        'name'               => __( 'Escrows', 'playmarket' ),
        'singular_name'      => __( 'Escrow', 'playmarket' ),
        'add_new'            => __( 'New Escrow', 'playmarket' ),
        'add_new_item'       => __( 'Add New Escrow', 'playmarket' ),
        'edit_item'          => __( 'Edit Escrow', 'playmarket' ),
        'view_item'          => __( 'View Escrow', 'playmarket' ),
        'search_items'       => __( 'Search Escrows', 'playmarket' ),
        'not_found'          => __( 'No escrows found', 'playmarket' ),
        'all_items'          => __( 'All Escrows', 'playmarket' ),
    );

    $args = array(
        'labels'              => $labels,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'menu_position'       => 20,
        'menu_icon'           => 'dashicons-shield',
        'supports'            => array( 'title', 'author', 'comments' ),
        'capability_type'     => 'post',
        'map_meta_cap'        => true,
        'rewrite'             => array( 'slug' => 'escrow' ),
        'has_archive'         => true,
        'exclude_from_search' => false,
    );

    register_post_type( 'pm_escrow', $args );
}
add_action( 'init', 'pm_register_escrow_post_type' );

/**
 * Register Dispute Custom Post Type
 */
function pm_register_dispute_post_type() {
    $labels = array(
        'name'               => __( 'Disputes', 'playmarket' ),
        'singular_name'      => __( 'Dispute', 'playmarket' ),
        'add_new'            => __( 'New Dispute', 'playmarket' ),
        'add_new_item'       => __( 'Add New Dispute', 'playmarket' ),
        'edit_item'          => __( 'Edit Dispute', 'playmarket' ),
        'view_item'          => __( 'View Dispute', 'playmarket' ),
        'search_items'       => __( 'Search Disputes', 'playmarket' ),
        'not_found'          => __( 'No disputes found', 'playmarket' ),
        'all_items'          => __( 'All Disputes', 'playmarket' ),
    );

    $args = array(
        'labels'              => $labels,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => false,
        'supports'            => array( 'title', 'editor', 'author', 'comments' ),
        'capability_type'     => 'post',
        'map_meta_cap'        => true,
        'rewrite'             => array( 'slug' => 'dispute' ),
        'has_archive'         => true,
        'exclude_from_search' => false,
    );

    register_post_type( 'pm_dispute', $args );
}
add_action( 'init', 'pm_register_dispute_post_type' );

/**
 * Custom Taxonomies: Game Category
 */
function pm_register_game_category_taxonomy() {
    $labels = array(
        'name'              => __( 'Game Categories', 'playmarket' ),
        'singular_name'     => __( 'Game Category', 'playmarket' ),
        'search_items'      => __( 'Search Categories', 'playmarket' ),
        'all_items'         => __( 'All Categories', 'playmarket' ),
        'edit_item'         => __( 'Edit Category', 'playmarket' ),
        'update_item'       => __( 'Update Category', 'playmarket' ),
        'add_new_item'      => __( 'Add New Category', 'playmarket' ),
        'menu_name'         => __( 'Categories', 'playmarket' ),
    );

    $args = array(
        'labels'            => $labels,
        'hierarchical'      => true,
        'public'            => true,
        'show_ui'           => true,
        'show_admin_column' => true,
        'rewrite'           => array( 'slug' => 'game-category' ),
    );

    register_taxonomy( 'pm_game_category', array( 'pm_escrow' ), $args );
}
add_action( 'init', 'pm_register_game_category_taxonomy' );

/**
 * Flush Rewrite Rules on theme activation
 */
function pm_activate() {
    pm_register_escrow_post_type();
    pm_register_dispute_post_type();
    pm_register_game_category_taxonomy();
    flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'pm_activate' );

/**
 * Theme cleanup: remove emoji junk, etc.
 */
function pm_cleanup() {
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
    remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
    remove_action( 'admin_print_styles', 'print_emoji_styles' );
}
add_action( 'init', 'pm_cleanup' );

/**
 * Disable XML-RPC for security
 */
add_filter( 'xmlrpc_enabled', '__return_false' );

/**
 * Remove generator version tags
 */
function pm_remove_version() {
    return '';
}
add_filter( 'the_generator', 'pm_remove_version' );

/**
 * SVG Icon: Sun (Light mode)
 */
function pm_icon_sun() {
    return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>';
}

/**
 * SVG Icon: Moon (Dark mode)
 */
function pm_icon_moon() {
    return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
}
