/**
 * PlayMarket Internationalization
 */
var PM_I18N = (function() {

    var lang = 'en';
    var currentLang = 'en';

    var strings = {

        /* ===== HEADER ===== */
        'header.logo': {
            en: 'PlayMarket',
            ru: 'PlayMarket',
            kk: 'PlayMarket',
        },
        'header.nav.home': { en: 'Home', ru: 'Главная', kk: 'Басты бет' },
        'header.nav.market': { en: 'Market', ru: 'Маркет', kk: 'Нарық' },
        'header.nav.news': { en: 'News', ru: 'Новости', kk: 'Жаңалықтар' },
        'header.nav.support': { en: 'Support', ru: 'Поддержка', kk: 'Қолдау' },
        'header.nav.my_deals': { en: 'My Deals', ru: 'Мои сделки', kk: 'Менің мәмілелерім' },
        'header.nav.escrow': { en: 'Escrow', ru: 'Эскроу', kk: 'Эскроу' },
        'header.lang_switcher': { en: 'Switch language', ru: 'Сменить язык', kk: 'Тілді ауыстыру' },
        'header.currency_switcher': { en: 'Switch currency', ru: 'Сменить валюту', kk: 'Валютаны ауыстыру' },
        'header.theme_toggle': { en: 'Toggle theme', ru: 'Переключить тему', kk: 'Тақырыпты ауыстыру' },
        'header.menu_toggle': { en: 'Toggle menu', ru: 'Меню', kk: 'Мәзір' },

        /* ===== FOOTER ===== */
        'footer.desc': {
            en: 'Modern marketplace for trading game accounts, currency, and P2P services. Secure escrow protection on every deal.',
            ru: 'Современная площадка для торговли игровыми аккаунтами, валютой и P2P-услугами. Надёжная защита эскроу в каждой сделке.',
            kk: 'Ойын аккаунттары, валюта және P2P қызметтерін сатуға арналған заманауи платформа. Әр мәміледе сенімді эскроу қорғанысы.',
        },
        'footer.marketplace': { en: 'Marketplace', ru: 'Маркетплейс', kk: 'Нарық' },
        'footer.browse_listings': { en: 'Browse Listings', ru: 'Все объявления', kk: 'Барлық хабарландырулар' },
        'footer.top_sellers': { en: 'Top Sellers', ru: 'Топ продавцы', kk: 'Үздік сатушылар' },
        'footer.how_escrow_works': { en: 'How Escrow Works', ru: 'Как работает эскроу', kk: 'Эскроу қалай жұмыс істейді' },
        'footer.dispute_rules': { en: 'Dispute Rules', ru: 'Правила споров', kk: 'Дау ережелері' },
        'footer.support': { en: 'Support', ru: 'Поддержка', kk: 'Қолдау' },
        'footer.help_center': { en: 'Help Center', ru: 'Центр помощи', kk: 'Көмек орталығы' },
        'footer.safety_tips': { en: 'Safety Tips', ru: 'Советы по безопасности', kk: 'Қауіпсіздік кеңестері' },
        'footer.contact_us': { en: 'Contact Us', ru: 'Связаться с нами', kk: 'Бізге хабарласыңыз' },
        'footer.report_problem': { en: 'Report a Problem', ru: 'Сообщить о проблеме', kk: 'Мәселе туралы хабарлау' },
        'footer.legal': { en: 'Legal', ru: 'Правовая информация', kk: 'Құқықтық ақпарат' },
        'footer.terms': { en: 'Terms of Service', ru: 'Условия использования', kk: 'Пайдалану шарттары' },
        'footer.privacy': { en: 'Privacy Policy', ru: 'Политика конфиденциальности', kk: 'Құпиялылық саясаты' },
        'footer.cookie': { en: 'Cookie Policy', ru: 'Политика Cookie', kk: 'Cookie саясаты' },
        'footer.refund': { en: 'Refund Policy', ru: 'Политика возврата', kk: 'Қайтару саясаты' },
        'footer.all_rights': { en: 'All rights reserved.', ru: 'Все права защищены.', kk: 'Барлық құқықтар қорғалған.' },

        /* ===== HERO ===== */
        'hero.badge': { en: 'Trusted Gaming Marketplace', ru: 'Надёжная игровая площадка', kk: 'Сенімді ойын платформасы' },
        'hero.title': { en: 'Trade Game Accounts & Currency', ru: 'Торгуй игровыми аккаунтами и валютой', kk: 'Ойын аккаунттары мен валютамен сауда жаса' },
        'hero.title_accent': { en: '100% Secured', ru: '100% Защита', kk: '100% Қорғаныс' },
        'hero.subtitle': { en: 'Buy and sell with confidence. Every transaction is protected by our Escrow security system — funds are frozen until you confirm delivery.', ru: 'Покупайте и продавайте с уверенностью. Каждая транзакция защищена нашей системой безопасности Escrow — средства заморожены до подтверждения получения.', kk: 'Сенімді сатып алыңыз және сатыңыз. Әрбір транзакция біздің Escrow қауіпсіздік жүйемен қорғалған — қаражат жеткізуді растағанға дейін бұғатталады.' },
        'hero.browse_btn': { en: 'Browse Listings', ru: 'Смотреть объявления', kk: 'Хабарландыруларды қарау' },
        'hero.sell_btn': { en: 'Start Selling', ru: 'Начать продавать', kk: 'Сатуды бастау' },
        'hero.stat_deals': { en: 'Completed Deals', ru: 'Завершённых сделок', kk: 'Аяқталған мәмілелер' },
        'hero.stat_success': { en: 'Success Rate', ru: 'Успешных сделок', kk: 'Сәтті мәмілелер' },
        'hero.stat_sellers': { en: 'Active Sellers', ru: 'Активных продавцов', kk: 'Белсенді сатушылар' },

        /* ===== FEATURES ===== */
        'features.tag': { en: 'Why PlayMarket', ru: 'Почему PlayMarket', kk: 'Неліктен PlayMarket' },
        'features.title': { en: 'Built for Safe, Fast Trading', ru: 'Создано для безопасной и быстрой торговли', kk: 'Қауіпсіз және жылдам сауда үшін жасалған' },
        'features.desc': { en: 'We eliminate risk in P2P gaming transactions with bank-grade security and automated arbitration.', ru: 'Мы устраняем риски в P2P-сделках с помощью банковской защиты и автоматического арбитража.', kk: 'Біз банктік деңгейдегі қауіпсіздік және автоматты арбитраж арқылы P2P мәмілелеріндегі тәуекелдерді жоямыз.' },
        'features.escrow_title': { en: 'Escrow Protection', ru: 'Защита Escrow', kk: 'Escrow қорғанысы' },
        'features.escrow_text': { en: 'Funds are locked in our secure escrow account the moment you pay. The seller gets nothing until you confirm everything is correct.', ru: 'Средства блокируются на нашем защищённом эскроу-счете в момент оплаты. Продавец ничего не получит, пока вы не подтвердите, что всё в порядке.', kk: 'Төлеген сәтте қаражат біздің қауіпсіз эскроу шотына бұғатталады. Сатушы бәрі дұрыс екенін растамайынша ештеңе алмайды.' },
        'features.clock_title': { en: '3-Hour Dispute Rule', ru: 'Правило 3 часов', kk: '3 сағат ережесі' },
        'features.clock_text': { en: 'If a party goes offline for more than 3 hours during an active deal, our arbitration matrix automatically rules in favor of the responsive party.', ru: 'Если одна из сторон не выходит на связь более 3 часов во время активной сделки, наш арбитраж автоматически принимает решение в пользу ответственной стороны.', kk: 'Егер тарап белсенді мәміле кезінде 3 сағаттан артық офлайн болса, біздің арбитраж автоматты түрде жауапты тараптың пайдасына шешім қабылдайды.' },
        'features.p2p_title': { en: 'Secure P2P Transactions', ru: 'Безопасные P2P сделки', kk: 'Қауіпсіз P2P мәмілелер' },
        'features.p2p_text': { en: 'Direct buyer-to-seller trading with full transparency. Chat, verify, and trade without intermediaries — backed by our guarantee.', ru: 'Прямая торговля между покупателем и продавцом с полной прозрачностью. Общайтесь, проверяйте и торгуйте без посредников — под нашей гарантией.', kk: 'Сатып алушы мен сатушы арасындағы толық ашық тікелей сауда. Делдалсыз сөйлесіңіз, тексеріңіз және сауда жасаңыз — біздің кепілдікпен.' },

        /* ===== ESCROW SECTION ===== */
        'escrow.tag': { en: 'How It Works', ru: 'Как это работает', kk: 'Қалай жұмыс істейді' },
        'escrow.title': { en: 'Escrow Security System', ru: 'Система безопасности Escrow', kk: 'Escrow қауіпсіздік жүйесі' },
        'escrow.desc': { en: 'Your money is never released until you confirm you have received exactly what you paid for.', ru: 'Ваши деньги не будут выплачены, пока вы не подтвердите, что получили именно то, за что заплатили.', kk: 'Сіз төлеген нәрсені алғаныңызды растамайынша, ақшаңыз босатылмайды.' },
        'escrow.step1_title': { en: 'Buyer Pays → Escrow Holds', ru: 'Покупатель платит → Escrow блокирует', kk: 'Сатып алушы төлейді → Escrow бұғаттайды' },
        'escrow.step1_text': { en: 'You send payment to the marketplace. Funds are frozen in our secure escrow account — the seller cannot access them.', ru: 'Вы отправляете платёж на площадку. Средства замораживаются на нашем защищённом эскроу-счете — продавец не может получить к ним доступ.', kk: 'Сіз платформаға төлем жібересіз. Қаражат біздің қауіпсіз эскроу шотында бұғатталады — сатушы оған қол жеткізе алмайды.' },
        'escrow.step2_title': { en: 'Seller Delivers → Buyer Verifies', ru: 'Продавец передаёт → Покупатель проверяет', kk: 'Сатушы жеткізеді → Сатып алушы тексереді' },
        'escrow.step2_text': { en: 'The seller provides the account, currency, or service. You have a verification window to inspect and confirm everything matches the listing.', ru: 'Продавец предоставляет аккаунт, валюту или услугу. У вас есть время на проверку, чтобы убедиться, что всё соответствует объявлению.', kk: 'Сатушы аккаунтты, валютаны немесе қызметті ұсынады. Барлығы хабарландыруға сәйкес келетінін тексеруге уақытыңыз бар.' },
        'escrow.step3_title': { en: 'Buyer Confirms → Seller Gets Paid', ru: 'Покупатель подтверждает → Продавец получает оплату', kk: 'Сатып алушы растайды → Сатушы төлем алады' },
        'escrow.step3_text': { en: 'Happy with the delivery? Click confirm. Funds are instantly released from escrow to the seller. Secure, fast, and fair.', ru: 'Довольны полученным? Нажмите «Подтвердить». Средства мгновенно переводятся из эскроу продавцу. Надёжно, быстро и честно.', kk: 'Жеткізуге көңіліңіз тола ма? Растауды басыңыз. Қаражат эскроудан сатушыға лезде аударылады. Қауіпсіз, жылдам және әділ.' },
        'escrow.note': { en: 'If anything goes wrong, funds stay frozen until the dispute is resolved. You are always protected.', ru: 'Если что-то пошло не так, средства остаются замороженными до разрешения спора. Вы всегда под защитой.', kk: 'Егер бірдеңе дұрыс болмаса, қаражат дау шешілгенше бұғатталған күйінде қалады. Сіз әрқашан қорғалғансыз.' },

        /* ===== DISPUTE SECTION ===== */
        'dispute.tag': { en: 'Fair Arbitration', ru: 'Справедливый арбитраж', kk: 'Әділ арбитраж' },
        'dispute.title': { en: 'The 3-Hour Dispute Rule', ru: 'Правило 3 часов', kk: '3 сағат ережесі' },
        'dispute.desc': { en: 'Trading should never stall. Our automated arbitration matrix ensures every dispute is resolved quickly and fairly.', ru: 'Торговля не должна останавливаться. Наш автоматический арбитраж гарантирует быстрое и справедливое разрешение каждого спора.', kk: 'Сауда тоқтап қалмауы керек. Біздің автоматты арбитраж әрбір даудың жылдам және әділ шешілуін қамтамасыз етеді.' },
        'dispute.rule_header': { en: 'The Clock Starts Ticking', ru: 'Часы начинают тикать', kk: 'Сағат санай бастайды' },
        'dispute.rule_text': { en: 'Once a dispute is opened, both parties have 3 hours to respond and provide evidence. The countdown is visible to everyone involved.', ru: 'Как только спор открыт, обе стороны имеют 3 часа на ответ и предоставление доказательств. Обратный отсчёт виден всем участникам.', kk: 'Дау ашылғаннан кейін екі тараптың да жауап беруіне және дәлелдер ұсынуына 3 сағаты бар. Кері санақ барлық қатысушыларға көрінеді.' },
        'dispute.matrix_title': { en: 'Arbitration Matrix', ru: 'Матрица арбитража', kk: 'Арбитраж матрицасы' },
        'dispute.buyer_wins': { en: 'Buyer Wins', ru: 'Покупатель выигрывает', kk: 'Сатып алушы жеңеді' },
        'dispute.buyer_wins_text': { en: 'Full refund if seller is unresponsive or fails to deliver as described.', ru: 'Полный возврат, если продавец не отвечает или не выполняет условия.', kk: 'Егер сатушы жауап бермесе немесе сипатталғандай жеткізбесе, толық қайтару.' },
        'dispute.seller_wins': { en: 'Seller Wins', ru: 'Продавец выигрывает', kk: 'Сатушы жеңеді' },
        'dispute.seller_wins_text': { en: 'Payment released if buyer is unresponsive after verified delivery.', ru: 'Оплата выплачивается, если покупатель не отвечает после подтверждённой доставки.', kk: 'Расталған жеткізуден кейін сатып алушы жауап бермесе, төлем босатылады.' },
        'dispute.split': { en: 'Split Decision', ru: 'Компромисс', kk: 'Ымыралы шешім' },
        'dispute.split_text': { en: 'Partial refund based on evidence weight when both parties share responsibility.', ru: 'Частичный возврат на основе веса доказательств, когда обе стороны несут ответственность.', kk: 'Екі тарап жауапты болғанда, дәлелдер салмағына негізделген ішінара қайтару.' },
        'dispute.manual': { en: 'Manual Review', ru: 'Ручная проверка', kk: 'Қолмен тексеру' },
        'dispute.manual_text': { en: 'Complex cases with evidence from both sides are escalated to our moderation team.', ru: 'Сложные случаи с доказательствами с обеих сторон передаются нашей команде модерации.', kk: 'Екі жақтан да дәлелдері бар күрделі жағдайлар біздің модерация тобына беріледі.' },
        'dispute.timer_header': { en: 'Active Dispute Timer', ru: 'Таймер активного спора', kk: 'Белсенді дау таймері' },
        'dispute.timer_hours': { en: 'Hours', ru: 'Часов', kk: 'Сағат' },
        'dispute.timer_mins': { en: 'Mins', ru: 'Мин', kk: 'Мин' },
        'dispute.timer_secs': { en: 'Secs', ru: 'Сек', kk: 'Сек' },
        'dispute.timer_note': { en: 'If the timer reaches zero, the responsive party automatically wins the dispute.', ru: 'Если таймер достигает нуля, ответственная сторона автоматически выигрывает спор.', kk: 'Егер таймер нөлге жетсе, жауапты тарап дауды автоматты түрде жеңеді.' },
        'dispute.rules_title': { en: 'Key Rules', ru: 'Основные правила', kk: 'Негізгі ережелер' },
        'dispute.rule1': { en: 'Both parties must respond within 3 hours of dispute opening.', ru: 'Обе стороны должны ответить в течение 3 часов после открытия спора.', kk: 'Екі тарап та дау ашылғаннан кейін 3 сағат ішінде жауап беруі керек.' },
        'dispute.rule2': { en: 'Provide screenshots, videos, or chat logs as evidence.', ru: 'Предоставьте скриншоты, видео или логи чата в качестве доказательств.', kk: 'Дәлел ретінде скриншоттар, бейнелер немесе чат журналдарын ұсыныңыз.' },
        'dispute.rule3': { en: 'Disputes escalate to manual review if both sides present evidence.', ru: 'Споры передаются на ручную проверку, если обе стороны предоставляют доказательства.', kk: 'Егер екі тарап та дәлелдер ұсынса, даулар қолмен тексеруге беріледі.' },
        'dispute.rule4': { en: 'Fraudulent disputes result in permanent account suspension.', ru: 'Мошеннические споры приводят к постоянной блокировке аккаунта.', kk: 'Алаяқтық даулар аккаунттың тұрақты бұғатталуына әкеледі.' },

        /* ===== CTA SECTION ===== */
        'cta.title': { en: 'Ready to Trade with Confidence?', ru: 'Готовы торговать с уверенностью?', kk: 'Сенімді сауда жасауға дайынсыз ба?' },
        'cta.text': { en: 'Join thousands of gamers buying and selling securely on PlayMarket. Zero risk, full protection.', ru: 'Присоединяйтесь к тысячам геймеров, которые безопасно покупают и продают на PlayMarket. Нулевой риск, полная защита.', kk: 'PlayMarket-те қауіпсіз сатып алатын және сататын мыңдаған ойыншыларға қосылыңыз. Нөлдік тәуекел, толық қорғаныс.' },
        'cta.btn_register': { en: 'Create Free Account', ru: 'Создать аккаунт бесплатно', kk: 'Аккаунтты тегін жасау' },
        'cta.btn_explore': { en: 'Explore Listings', ru: 'Смотреть объявления', kk: 'Хабарландыруларды қарау' },

        /* ===== MARKET PAGE ===== */
        'market.tag': { en: 'Marketplace', ru: 'Маркетплейс', kk: 'Нарық' },
        'market.title': { en: 'Browse Game Accounts & Services', ru: 'Поиск игровых аккаунтов и услуг', kk: 'Ойын аккаунттары мен қызметтерді іздеу' },
        'market.desc': { en: 'Find verified sellers, compare prices, and trade securely with escrow protection on every listing.', ru: 'Находите проверенных продавцов, сравнивайте цены и торгуйте безопасно с защитой эскроу в каждом объявлении.', kk: 'Расталған сатушыларды табыңыз, бағаларды салыстырыңыз және әр хабарландыруда эскроу қорғанысымен қауіпсіз сауда жасаңыз.' },
        'market.filter_platform': { en: 'Platform', ru: 'Платформа', kk: 'Платформа' },
        'market.filter_game': { en: 'Game', ru: 'Игра', kk: 'Ойын' },
        'market.filter_rank': { en: 'Rank', ru: 'Ранг', kk: 'Дәреже' },
        'market.filter_min_price': { en: 'Min Price', ru: 'Мин. цена', kk: 'Мин. баға' },
        'market.filter_max_price': { en: 'Max Price', ru: 'Макс. цена', kk: 'Макс. баға' },
        'market.filter_all_platforms': { en: 'All Platforms', ru: 'Все платформы', kk: 'Барлық платформалар' },
        'market.filter_all_games': { en: 'All Games', ru: 'Все игры', kk: 'Барлық ойындар' },
        'market.filter_all_ranks': { en: 'All Ranks', ru: 'Все ранги', kk: 'Барлық дәрежелер' },
        'market.apply': { en: 'Apply', ru: 'Применить', kk: 'Қолдану' },
        'market.reset': { en: 'Reset', ru: 'Сбросить', kk: 'Қалпына келтіру' },
        'market.sort_by': { en: 'Sort by', ru: 'Сортировать по', kk: 'Сұрыптау' },
        'market.sort_newest': { en: 'Newest', ru: 'Новые', kk: 'Жаңалары' },
        'market.sort_price_asc': { en: 'Price: Low → High', ru: 'Цена: по возрастанию', kk: 'Баға: өсу бойынша' },
        'market.sort_price_desc': { en: 'Price: High → Low', ru: 'Цена: по убыванию', kk: 'Баға: кему бойынша' },
        'market.sort_rating': { en: 'Top Rated', ru: 'По рейтингу', kk: 'Рейтинг бойынша' },
        'market.view_deal': { en: 'View Deal', ru: 'Смотреть', kk: 'Қарау' },
        'market.prev': { en: 'Previous', ru: 'Назад', kk: 'Артқа' },
        'market.next': { en: 'Next', ru: 'Вперёд', kk: 'Алға' },
        'market.escrow_badge': { en: 'Escrow', ru: 'Эскроу', kk: 'Эскроу' },
        'market.verified_badge': { en: 'Verified', ru: 'Проверен', kk: 'Расталған' },
        'market.instant_badge': { en: 'Instant', ru: 'Мгновенно', kk: 'Лезде' },

        /* ===== NEWS PAGE ===== */
        'news.tag': { en: 'News & Updates', ru: 'Новости и обновления', kk: 'Жаңалықтар мен жаңартулар' },
        'news.title': { en: 'PlayMarket Newsroom', ru: 'Новости PlayMarket', kk: 'PlayMarket жаңалықтары' },
        'news.desc': { en: 'Stay informed with the latest platform updates, security announcements, and gaming market trends.', ru: 'Будьте в курсе последних обновлений платформы, объявлений о безопасности и трендов игрового рынка.', kk: 'Платформаның соңғы жаңартулары, қауіпсіздік хабарландырулары және ойын нарығының трендтері туралы хабардар болыңыз.' },
        'news.prev': { en: 'Previous', ru: 'Назад', kk: 'Артқа' },
        'news.next': { en: 'Next', ru: 'Вперёд', kk: 'Алға' },

        /* ===== SUPPORT PAGE ===== */
        'support.tag': { en: 'Support & Moderation', ru: 'Поддержка и модерация', kk: 'Қолдау және модерация' },
        'support.title': { en: 'Meet the Team', ru: 'Наша команда', kk: 'Біздің команда' },
        'support.desc': { en: 'Our dedicated administration and moderation team works around the clock to ensure safe, fair trading for every PlayMarket user.', ru: 'Наша команда администрации и модерации работает круглосуточно, чтобы обеспечить безопасную и честную торговлю для каждого пользователя PlayMarket.', kk: 'Біздің әкімшілік және модерация тобы әрбір PlayMarket пайдаланушысы үшін қауіпсіз және әділ сауданы қамтамасыз ету үшін тәулік бойы жұмыс істейді.' },
        'support.stats_resolved': { en: 'Disputes Resolved', ru: 'Споров решено', kk: 'Даулар шешілді' },
        'support.stats_avg_time': { en: 'Avg. Resolution Time', ru: 'Среднее время решения', kk: 'Орташа шешу уақыты' },
        'support.stats_satisfaction': { en: 'Satisfaction Rate', ru: 'Уровень удовлетворённости', kk: 'Қанағаттану деңгейі' },
        'support.stats_members': { en: 'Team Members', ru: 'Членов команды', kk: 'Команда мүшелері' },
        'support.admin_heading': { en: 'Administration', ru: 'Администрация', kk: 'Әкімшілік' },
        'support.admin_desc': { en: 'The leadership team responsible for platform strategy, policy, and overall community well-being.', ru: 'Руководящая команда, отвечающая за стратегию платформы, политику и благополучие сообщества.', kk: 'Платформа стратегиясы, саясаты және жалпы қоғамдастықтың әл-ауқаты үшін жауапты басшылық топ.' },
        'support.mod_heading': { en: 'Moderation & Arbitration', ru: 'Модерация и арбитраж', kk: 'Модерация және арбитраж' },
        'support.mod_desc': { en: 'Our trained moderators and arbiters handle disputes, enforce rules, and ensure every transaction is fair. They monitor platform operations 24/7 and are empowered to resolve issues under the 3-Hour Dispute Rule.', ru: 'Наши обученные модераторы и арбитры рассматривают споры, следят за соблюдением правил и обеспечивают честность каждой сделки. Они круглосуточно следят за работой платформы и уполномочены решать проблемы в соответствии с Правилом 3 часов.', kk: 'Біздің оқытылған модераторлар мен арбитрлер дауларды қарайды, ережелердің сақталуын қадағалайды және әрбір мәміленің әділдігін қамтамасыз етеді. Олар платформа жұмысын 24/7 бақылайды және 3 сағат ережесі бойынша мәселелерді шешуге құқылы.' },
        'support.cta_title': { en: 'Need Help?', ru: 'Нужна помощь?', kk: 'Көмек керек пе?' },
        'support.cta_text': { en: 'If you have an active dispute or need immediate assistance, open a support ticket and our team will respond within 2 hours.', ru: 'Если у вас активный спор или нужна срочная помощь, откройте тикет поддержки, и наша команда ответит в течение 2 часов.', kk: 'Егер сізде белсенді дау болса немесе шұғыл көмек қажет болса, қолдау тикетін ашыңыз, біздің команда 2 сағат ішінде жауап береді.' },
        'support.ticket_btn': { en: 'Open Support Ticket', ru: 'Открыть тикет', kk: 'Қолдау тикетін ашу' },
    };

    function getLang() {
        try { return localStorage.getItem('pm_lang') || 'en'; } catch(e) { return 'en'; }
    }

    function setLang(l) {
        if (l !== 'en' && l !== 'ru' && l !== 'kk') l = 'en';
        try { localStorage.setItem('pm_lang', l); } catch(e) {}
        currentLang = l;
        translatePage(l);
    }

    function translatePage(l) {
        var elements = document.querySelectorAll('[data-i18n]');
        for (var i = 0; i < elements.length; i++) {
            var el = elements[i];
            var key = el.getAttribute('data-i18n');
            if (!key) continue;
            var s = strings[key];
            if (!s) continue;
            var t = s[l] || s.en;
            if (t !== undefined && t !== null) {
                el.textContent = t;
            }
        }
        updatePlaceholders(l);
    }

    function updatePlaceholders(l) {
        var inputs = document.querySelectorAll('[data-i18n-placeholder]');
        for (var i = 0; i < inputs.length; i++) {
            var el = inputs[i];
            var key = el.getAttribute('data-i18n-placeholder');
            var s = strings[key];
            if (!s) continue;
            var t = s[l] || s.en;
            if (t !== undefined) {
                el.setAttribute('placeholder', t);
            }
        }
    }

    function init() {
        currentLang = getLang();
        if (currentLang !== 'en') {
            translatePage(currentLang);
        }
        updateLangLabel(currentLang);
    }

    function updateLangLabel(l) {
        var labels = document.querySelectorAll('.pm-lang-switcher .pm-dropdown-label');
        for (var i = 0; i < labels.length; i++) {
            labels[i].textContent = l.toUpperCase();
        }
        var opts = document.querySelectorAll('.pm-lang-option');
        for (var i = 0; i < opts.length; i++) {
            opts[i].classList.toggle('active', opts[i].getAttribute('data-lang') === l);
        }
    }

    return {
        init: init,
        setLang: setLang,
        getLang: getLang,
        translate: translatePage,
    };

})();
