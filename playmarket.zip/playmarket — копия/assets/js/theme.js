/**
 * PlayMarket Theme JavaScript
 */
(function() {

    var html = document.documentElement;

    /* ===== THEME TOGGLE ===== */
    var themeToggle = document.getElementById('pm-theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            var current = html.getAttribute('data-theme');
            var next = (current === 'dark') ? 'light' : 'dark';
            html.setAttribute('data-theme', next);
            try { localStorage.setItem('pm-theme', next); } catch(e) {}
        });
    }

    var storedTheme = null;
    try { storedTheme = localStorage.getItem('pm-theme'); } catch(e) {}
    if (storedTheme === 'light' || storedTheme === 'dark') {
        html.setAttribute('data-theme', storedTheme);
    }

    /* ===== LANGUAGE SWITCHER ===== */
    var langTriggers = document.querySelectorAll('.pm-lang-option');
    langTriggers.forEach(function(el) {
        el.addEventListener('click', function(e) {
            e.preventDefault();
            var lang = el.getAttribute('data-lang');
            if (typeof PM_I18N !== 'undefined') {
                PM_I18N.setLang(lang);
            }
        });
    });

    /* ===== CURRENCY SWITCHER ===== */
    var currTriggers = document.querySelectorAll('.pm-currency-option');
    var currLabel = document.querySelector('.pm-currency-switcher .pm-dropdown-label');
    currTriggers.forEach(function(el) {
        el.addEventListener('click', function(e) {
            e.preventDefault();
            currTriggers.forEach(function(t) { t.classList.remove('active'); });
            el.classList.add('active');
            if (currLabel) currLabel.textContent = el.getAttribute('data-currency');
            var menu = document.querySelector('.pm-currency-switcher .pm-dropdown-menu');
            if (menu) menu.classList.remove('open');
        });
    });

    /* ===== DROPDOWNS ===== */
    var dropdownTriggers = document.querySelectorAll('.pm-dropdown-trigger');
    dropdownTriggers.forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            var menu = this.parentElement.querySelector('.pm-dropdown-menu');
            if (menu) {
                var open = document.querySelectorAll('.pm-dropdown-menu.open');
                open.forEach(function(m) { if (m !== menu) m.classList.remove('open'); });
                menu.classList.toggle('open');
            }
        });
    });

    document.addEventListener('click', function() {
        document.querySelectorAll('.pm-dropdown-menu.open').forEach(function(m) {
            m.classList.remove('open');
        });
    });

    /* ===== MOBILE MENU ===== */
    var mobileToggle = document.getElementById('pm-mobile-toggle');
    var mobileNav = document.getElementById('pm-primary-nav');
    var mobileOverlay = document.getElementById('pm-mobile-overlay');
    if (mobileToggle && mobileNav) {
        mobileToggle.addEventListener('click', function() {
            mobileNav.classList.toggle('open');
            if (mobileOverlay) mobileOverlay.classList.toggle('open');
        });
        if (mobileOverlay) {
            mobileOverlay.addEventListener('click', function() {
                mobileNav.classList.remove('open');
                mobileOverlay.classList.remove('open');
            });
        }
    }

    /* ===== SCROLL ANIMATIONS ===== */
    var animateElements = function() {
        var els = document.querySelectorAll('.pm-animate-once');
        if (els.length === 0) return;
        var observer = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('pm-animated');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.15 });
        els.forEach(function(el) { observer.observe(el); });
    };

    if ('IntersectionObserver' in window) {
        animateElements();
    } else {
        document.querySelectorAll('.pm-animate-once').forEach(function(el) {
            el.classList.add('pm-animated');
        });
    }

    /* ===== INIT I18N ===== */
    if (typeof PM_I18N !== 'undefined') {
        PM_I18N.init();
    }

})();
