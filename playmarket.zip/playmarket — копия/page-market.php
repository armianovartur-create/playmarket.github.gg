<?php
/**
 * Template Name: Market Catalog
 *
 * @package PlayMarket
 * @since 1.0.0
 */

get_header();

$platforms = array( 'PC', 'PlayStation', 'Xbox', 'Mobile' );
$games = array(
    'League of Legends'    => 'PC',
    'CS2'                  => 'PC',
    'World of Warcraft'    => 'PC',
    'Elden Ring'           => 'PlayStation',
    'Valorant'             => 'PC',
    'Genshin Impact'       => 'Mobile',
    'Dota 2'               => 'PC',
    'Call of Duty'         => 'Xbox',
    'Mobile Legends'       => 'Mobile',
    'PUBG Mobile'          => 'Mobile',
    'Fortnite'             => 'PlayStation',
    'Apex Legends'         => 'PC',
    'FIFA 24'              => 'Xbox',
    'Honor of Kings'       => 'Mobile',
    'Rust'                 => 'PC',
);
$ranks = array( 'Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Master', 'Grandmaster', 'Challenger', 'Mythic', 'Radiant' );
$usernames = array( 'ProTrader', 'GameVault', 'EliteBoost', 'RankUp', 'AccountKing', 'SkyBoost', 'NeonSeller', 'DarkMarket', 'PixelDeal', 'FastBoost', 'ZenTrader', 'AceBoost' );
$adjectives = array( 'Legit', 'Fresh', 'Maxed', 'Unranked', 'Veteran', 'Starter', 'Premium', 'Ultimate', 'Rare', 'Exclusive' );

$listings = array();
for ( $i = 1; $i <= 24; $i++ ) {
    $game_keys = array_keys( $games );
    $game = $game_keys[ array_rand( $game_keys ) ];
    $platform = $games[ $game ];
    $rank = $ranks[ array_rand( $ranks ) ];
    $adj = $adjectives[ array_rand( $adjectives ) ];
    $user = $usernames[ array_rand( $usernames ) ];
    $price = rand( 1500, 85000 );
    $reviews = rand( 12, 340 );
    $rating = round( 4.2 + ( rand( 0, 8 ) / 10 ), 1 );
    if ( $rating > 5.0 ) { $rating = 5.0; }
    $badges = array();
    if ( rand( 0, 1 ) ) { $badges[] = 'escrow'; }
    if ( rand( 0, 1 ) ) { $badges[] = 'verified'; }
    if ( rand( 0, 1 ) ) { $badges[] = 'instant'; }

    $listings[] = array(
        'id'       => $i,
        'game'     => $game,
        'platform' => $platform,
        'rank'     => $rank,
        'title'    => "$adj $rank $game Account",
        'price'    => $price,
        'seller'   => $user,
        'reviews'  => $reviews,
        'rating'   => $rating,
        'badges'   => $badges,
    );
}

$game_options = array_keys( $games );
sort( $game_options );
?>

<section class="pm-section pm-market-page">
    <div class="pm-container">

        <div class="pm-section-header">
            <span class="pm-section-tag" data-i18n="market.tag"><?php esc_html_e( 'Marketplace', 'playmarket' ); ?></span>
            <h1 class="pm-section-title" data-i18n="market.title"><?php esc_html_e( 'Browse Game Accounts & Services', 'playmarket' ); ?></h1>
            <p class="pm-section-desc" data-i18n="market.desc"><?php esc_html_e( 'Find verified sellers, compare prices, and trade securely with escrow protection on every listing.', 'playmarket' ); ?></p>
        </div>

        <div class="pm-market-toolbar">
            <div class="pm-market-filters">
                <div class="pm-filter-group">
                    <label class="pm-filter-label" for="filter-platform" data-i18n="market.filter_platform"><?php esc_html_e( 'Platform', 'playmarket' ); ?></label>
                    <select class="pm-input pm-select pm-filter-select" id="filter-platform">
                        <option value="" data-i18n="market.filter_all_platforms"><?php esc_html_e( 'All Platforms', 'playmarket' ); ?></option>
                        <?php foreach ( $platforms as $p ) : ?>
                            <option value="<?php echo esc_attr( $p ); ?>"><?php echo esc_html( $p ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="pm-filter-group">
                    <label class="pm-filter-label" for="filter-game" data-i18n="market.filter_game"><?php esc_html_e( 'Game', 'playmarket' ); ?></label>
                    <select class="pm-input pm-select pm-filter-select" id="filter-game">
                        <option value="" data-i18n="market.filter_all_games"><?php esc_html_e( 'All Games', 'playmarket' ); ?></option>
                        <?php foreach ( $game_options as $g ) : ?>
                            <option value="<?php echo esc_attr( $g ); ?>"><?php echo esc_html( $g ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="pm-filter-group">
                    <label class="pm-filter-label" for="filter-rank" data-i18n="market.filter_rank"><?php esc_html_e( 'Rank', 'playmarket' ); ?></label>
                    <select class="pm-input pm-select pm-filter-select" id="filter-rank">
                        <option value="" data-i18n="market.filter_all_ranks"><?php esc_html_e( 'All Ranks', 'playmarket' ); ?></option>
                        <?php foreach ( $ranks as $r ) : ?>
                            <option value="<?php echo esc_attr( $r ); ?>"><?php echo esc_html( $r ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="pm-filter-group">
                    <label class="pm-filter-label" for="filter-price-min" data-i18n="market.filter_min_price"><?php esc_html_e( 'Min Price', 'playmarket' ); ?></label>
                    <input class="pm-input pm-filter-input" id="filter-price-min" type="number" min="0" step="100" placeholder="0 KZT">
                </div>
                <div class="pm-filter-group">
                    <label class="pm-filter-label" for="filter-price-max" data-i18n="market.filter_max_price"><?php esc_html_e( 'Max Price', 'playmarket' ); ?></label>
                    <input class="pm-input pm-filter-input" id="filter-price-max" type="number" min="0" step="100" placeholder="∞">
                </div>
                <div class="pm-filter-actions">
                    <button class="pm-btn pm-btn-primary pm-btn-sm" id="pm-filter-apply" data-i18n="market.apply"><?php esc_html_e( 'Apply', 'playmarket' ); ?></button>
                    <button class="pm-btn pm-btn-secondary pm-btn-sm" id="pm-filter-reset" data-i18n="market.reset"><?php esc_html_e( 'Reset', 'playmarket' ); ?></button>
                </div>
            </div>
            <div class="pm-market-sort">
                <label class="pm-filter-label" for="filter-sort" data-i18n="market.sort_by"><?php esc_html_e( 'Sort by', 'playmarket' ); ?></label>
                <select class="pm-input pm-select pm-filter-select" id="filter-sort">
                    <option value="newest" data-i18n="market.sort_newest"><?php esc_html_e( 'Newest', 'playmarket' ); ?></option>
                    <option value="price-asc" data-i18n="market.sort_price_asc"><?php esc_html_e( 'Price: Low → High', 'playmarket' ); ?></option>
                    <option value="price-desc" data-i18n="market.sort_price_desc"><?php esc_html_e( 'Price: High → Low', 'playmarket' ); ?></option>
                    <option value="rating" data-i18n="market.sort_rating"><?php esc_html_e( 'Top Rated', 'playmarket' ); ?></option>
                </select>
            </div>
        </div>

        <div class="pm-market-grid" id="pm-market-grid">
            <?php foreach ( $listings as $item ) : ?>
            <div class="pm-market-item pm-animate-once pm-fade-in-up" style="animation-delay: calc(0.05s * <?php echo $item['id']; ?>)" data-platform="<?php echo esc_attr( $item['platform'] ); ?>" data-game="<?php echo esc_attr( $item['game'] ); ?>" data-rank="<?php echo esc_attr( $item['rank'] ); ?>" data-price="<?php echo esc_attr( $item['price'] ); ?>" data-rating="<?php echo esc_attr( $item['rating'] ); ?>">
                <div class="pm-market-item-thumb">
                    <div class="pm-market-item-platform"><?php echo esc_html( $item['platform'] ); ?></div>
                    <div class="pm-market-item-initials"><?php echo esc_html( substr( $item['game'], 0, 2 ) ); ?></div>
                </div>
                <div class="pm-market-item-body">
                    <div class="pm-market-item-game"><?php echo esc_html( $item['game'] ); ?></div>
                    <h3 class="pm-market-item-title"><?php echo esc_html( $item['title'] ); ?></h3>
                    <div class="pm-market-item-meta">
                        <span class="pm-market-item-rank">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            <?php echo esc_html( $item['rank'] ); ?>
                        </span>
                        <span class="pm-market-item-reviews">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                            <?php echo esc_html( $item['reviews'] ); ?>
                        </span>
                        <span class="pm-market-item-rating">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            <?php echo esc_html( $item['rating'] ); ?>
                        </span>
                    </div>
                </div>
                <div class="pm-market-item-footer">
                    <div class="pm-market-item-badges">
                        <?php if ( in_array( 'escrow', $item['badges'], true ) ) : ?>
                            <span class="pm-badge pm-badge-escrow" data-i18n="market.escrow_badge"><?php esc_html_e( 'Escrow', 'playmarket' ); ?></span>
                        <?php endif; ?>
                        <?php if ( in_array( 'verified', $item['badges'], true ) ) : ?>
                            <span class="pm-badge pm-badge-escrow" style="border-color:rgba(68,136,255,0.25);color:var(--pm-info);background:rgba(68,136,255,0.1);" data-i18n="market.verified_badge"><?php esc_html_e( 'Verified', 'playmarket' ); ?></span>
                        <?php endif; ?>
                        <?php if ( in_array( 'instant', $item['badges'], true ) ) : ?>
                            <span class="pm-badge pm-badge-escrow" style="border-color:rgba(255,170,0,0.25);color:var(--pm-warning);background:rgba(255,170,0,0.1);" data-i18n="market.instant_badge"><?php esc_html_e( 'Instant', 'playmarket' ); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="pm-market-item-seller">
                        <span class="pm-market-item-seller-name"><?php echo esc_html( $item['seller'] ); ?></span>
                    </div>
                    <div class="pm-market-item-price">
                        <?php echo esc_html( number_format( $item['price'] ) ); ?>
                        <span>KZT</span>
                    </div>
                    <a href="#" class="pm-btn pm-btn-primary pm-btn-sm pm-w-full" data-i18n="market.view_deal"><?php esc_html_e( 'View Deal', 'playmarket' ); ?></a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="pm-market-pagination">
            <button class="pm-btn pm-btn-secondary pm-btn-sm" disabled>&larr; <span data-i18n="market.prev"><?php esc_html_e( 'Previous', 'playmarket' ); ?></span></button>
            <div class="pm-market-pages">
                <span class="pm-market-page active">1</span>
                <span class="pm-market-page">2</span>
                <span class="pm-market-page">3</span>
                <span class="pm-market-page">4</span>
                <span class="pm-market-page">…</span>
                <span class="pm-market-page">12</span>
            </div>
            <button class="pm-btn pm-btn-secondary pm-btn-sm"><span data-i18n="market.next"><?php esc_html_e( 'Next', 'playmarket' ); ?></span> &rarr;</button>
        </div>

    </div>
</section>

<?php
get_footer();
