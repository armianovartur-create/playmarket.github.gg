<!DOCTYPE html>
<html <?php language_attributes(); ?> data-theme="dark">
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php
if ( function_exists( 'wp_body_open' ) ) {
    wp_body_open();
}
?>

<div id="pm-page" class="pm-site">

<header class="pm-header">
    <div class="pm-header-inner">

        <div class="pm-header-left">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="pm-logo-link" rel="home">
                <img
                    class="pm-logo-img"
                    src="<?php echo esc_url( get_theme_file_uri( 'assets/images/logo.png' ) ); ?>"
                    alt="<?php bloginfo( 'name' ); ?>"
                    width="160"
                    height="36"
                />
                <span class="pm-logo-text">Play<span>Market</span></span>
            </a>
        </div>

        <nav class="pm-nav" id="pm-primary-nav">
            <?php
            if ( has_nav_menu( 'primary' ) ) {
                wp_nav_menu( array(
                    'theme_location' => 'primary',
                    'menu_class'     => 'pm-nav-list',
                    'container'      => false,
                    'fallback_cb'    => false,
                    'depth'          => 3,
                ) );
            } else {
                echo '<ul class="pm-nav-list">';
                wp_list_pages( array(
                    'title_li' => '',
                    'depth'    => 2,
                ) );
                echo '</ul>';
            }
            ?>
        </nav>

        <div class="pm-header-tools">

            <div class="pm-dropdown pm-lang-switcher">
                <button class="pm-dropdown-trigger" type="button" aria-label="<?php esc_attr_e( 'Switch language', 'playmarket' ); ?>">
                    <svg class="pm-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
                    </svg>
                    <span class="pm-dropdown-label">RU</span>
                </button>
                <ul class="pm-dropdown-menu pm-lang-menu">
                    <li><a href="#" data-lang="ru" class="pm-lang-option active">Русский</a></li>
                    <li><a href="#" data-lang="kk" class="pm-lang-option">Қазақша</a></li>
                </ul>
            </div>

            <div class="pm-dropdown pm-currency-switcher">
                <button class="pm-dropdown-trigger" type="button" aria-label="<?php esc_attr_e( 'Switch currency', 'playmarket' ); ?>">
                    <span class="pm-dropdown-label">KZT</span>
                    <svg class="pm-chevron" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                </button>
                <ul class="pm-dropdown-menu pm-currency-menu">
                    <li><a href="#" data-currency="KZT" class="pm-currency-option active">KZT</a></li>
                    <li><a href="#" data-currency="RUB" class="pm-currency-option">RUB</a></li>
                    <li><a href="#" data-currency="USD" class="pm-currency-option">USD</a></li>
                    <li><a href="#" data-currency="UAH" class="pm-currency-option">UAH</a></li>
                    <li><a href="#" data-currency="BYN" class="pm-currency-option">BYN</a></li>
                    <li><a href="#" data-currency="EUR" class="pm-currency-option">EUR</a></li>
                    <li><a href="#" data-currency="CNY" class="pm-currency-option">CNY</a></li>
                </ul>
            </div>

            <button class="pm-theme-toggle" type="button" id="pm-theme-toggle" aria-label="<?php esc_attr_e( 'Toggle theme', 'playmarket' ); ?>">
                <span class="pm-sun-icon"><?php echo pm_icon_sun(); ?></span>
                <span class="pm-moon-icon"><?php echo pm_icon_moon(); ?></span>
            </button>

            <button class="pm-mobile-toggle" type="button" id="pm-mobile-toggle" aria-label="<?php esc_attr_e( 'Toggle menu', 'playmarket' ); ?>">
                <span></span><span></span><span></span>
            </button>

        </div>

    </div>
</header>

<main class="pm-main">
