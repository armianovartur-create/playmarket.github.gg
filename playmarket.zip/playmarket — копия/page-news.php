<?php
/**
 * Template Name: News
 *
 * @package PlayMarket
 * @since 1.0.0
 */

get_header();

$categories = array( 'Security', 'Updates', 'Games', 'Community', 'Trading', 'Events' );

$articles = array(
    array(
        'title'     => 'New Escrow Security Update: Biometric Verification Now Live',
        'excerpt'   => 'PlayMarket introduces mandatory 2FA and optional biometric verification for all high-value escrow transactions exceeding 50,000 KZT, adding an extra layer of protection for buyers and sellers.',
        'category'  => 'Security',
        'date'      => 'June 15, 2026',
        'author'    => 'Alexei Volkov',
        'featured'  => true,
        'image'     => 'ES',
    ),
    array(
        'title'     => 'Elden Ring DLC Accounts Now Trading on PlayMarket',
        'excerpt'   => 'With the massive success of the Shadow of the Erdtree expansion, Elden Ring account listings have surged 340%. Verified sellers are offering maxed characters with full DLC completion.',
        'category'  => 'Games',
        'date'      => 'June 12, 2026',
        'author'    => 'Yuki Tanaka',
        'featured'  => false,
        'image'     => 'ER',
    ),
    array(
        'title'     => '3-Hour Dispute Rule: What Changed in the June 2026 Update',
        'excerpt'   => 'The arbitration matrix has been updated with clearer evidence submission guidelines. Both parties now receive automated reminders at 1-hour intervals during active disputes.',
        'category'  => 'Updates',
        'date'      => 'June 8, 2026',
        'author'    => 'Alexei Volkov',
        'featured'  => false,
        'image'     => '3H',
    ),
    array(
        'title'     => 'Community Update: Top 10 Sellers of May 2026',
        'excerpt'   => 'Our monthly ranking highlights the most reliable sellers based on completion rate, response time, and community feedback. Congratulations to all top performers!',
        'category'  => 'Community',
        'date'      => 'June 1, 2026',
        'author'    => 'Maria Petrova',
        'featured'  => false,
        'image'     => 'T10',
    ),
    array(
        'title'     => 'CS2 Skin Trading: New Verification Standards Announced',
        'excerpt'   => 'Following the recent surge in CS2 skin trades, PlayMarket is implementing mandatory screenshot verification and live inventory checks for all skin-related listings.',
        'category'  => 'Trading',
        'date'      => 'May 27, 2026',
        'author'    => 'Dmitri Kozlov',
        'featured'  => false,
        'image'     => 'CS',
    ),
    array(
        'title'     => 'Mobile Legends: Mythic Account Demand Hits All-Time High',
        'excerpt'   => 'Mobile Legends: Bang Bang account listings have grown 500% year-over-year. Mythic and Glory-ranked accounts are selling at record prices on the platform.',
        'category'  => 'Games',
        'date'      => 'May 20, 2026',
        'author'    => 'Yuki Tanaka',
        'featured'  => false,
        'image'     => 'ML',
    ),
    array(
        'title'     => 'Platform Update: New Chat System with Encrypted Messaging',
        'excerpt'   => 'Our new end-to-end encrypted messaging system ensures all buyer-seller communications remain private and tamper-proof. Messages are automatically included as dispute evidence.',
        'category'  => 'Updates',
        'date'      => 'May 14, 2026',
        'author'    => 'Alexei Volkov',
        'featured'  => false,
        'image'     => 'CH',
    ),
    array(
        'title'     => 'LoL Account Trading: Riot Policy Changes and What It Means',
        'excerpt'   => 'An in-depth analysis of recent Riot Games account policy updates and how PlayMarket\'s escrow system continues to provide safe trading within the new guidelines.',
        'category'  => 'Trading',
        'date'      => 'May 8, 2026',
        'author'    => 'Maria Petrova',
        'featured'  => false,
        'image'     => 'Lo',
    ),
    array(
        'title'     => 'PlayMarket x Cyber Security Summit: Protecting Digital Assets',
        'excerpt'   => 'Our CTO presented at the 2026 Cyber Security Summit, demonstrating how marketplace escrow systems can prevent fraud in digital goods trading.',
        'category'  => 'Events',
        'date'      => 'April 28, 2026',
        'author'    => 'Dmitri Kozlov',
        'featured'  => false,
        'image'     => 'CY',
    ),
    array(
        'title'     => 'WoW Hardcore Mode: Fresh Accounts Now Available',
        'excerpt'   => 'With World of Warcraft Hardcore servers at peak population, sellers are listing max-level Hardcore characters with full raid clears and rare mounts.',
        'category'  => 'Games',
        'date'      => 'April 19, 2026',
        'author'    => 'Yuki Tanaka',
        'featured'  => false,
        'image'     => 'Wo',
    ),
    array(
        'title'     => 'Escrow Fees Reduced: New Tiered Pricing Starts May 1',
        'excerpt'   => 'Good news for high-volume traders. Our new fee structure drops escrow fees to as low as 1.5% for premium sellers and repeat buyers. Full details inside.',
        'category'  => 'Updates',
        'date'      => 'April 15, 2026',
        'author'    => 'Alexei Volkov',
        'featured'  => false,
        'image'     => 'FE',
    ),
    array(
        'title'     => 'Valorant Radiant Accounts: Demand Surges 200% This Quarter',
        'excerpt'   => 'Radiant-ranked Valorant accounts are the hottest commodity on PlayMarket this spring. Verified sellers report record sales volumes and faster deal closures.',
        'category'  => 'Trading',
        'date'      => 'April 10, 2026',
        'author'    => 'Maria Petrova',
        'featured'  => false,
        'image'     => 'Va',
    ),
    array(
        'title'     => 'RU to KZT Conversion: New Automatic Payment Processing',
        'excerpt'   => 'PlayMarket now supports automatic RUB to KZT conversion for cross-border trades, making it seamless for Russian and Kazakh users to transact without manual exchange.',
        'category'  => 'Updates',
        'date'      => 'April 5, 2026',
        'author'    => 'Dmitri Kozlov',
        'featured'  => false,
        'image'     => 'CU',
    ),
    array(
        'title'     => 'Community Guidelines Update: Stricter Rules for New Sellers',
        'excerpt'   => 'Starting April 2026, new sellers must complete identity verification and a 7-day probation period before listing high-value items. Full policy details here.',
        'category'  => 'Community',
        'date'      => 'April 2, 2026',
        'author'    => 'Alexei Volkov',
        'featured'  => false,
        'image'     => 'CG',
    ),
    array(
        'title'     => 'April Fools 2026: PlayMarket Launches "Trust-Mascot" AI Bot',
        'excerpt'   => 'Our AI-powered chatbot "Trusty" briefly appeared on the platform offering sarcastic trading advice. The community loved it so much we might keep her around.',
        'category'  => 'Community',
        'date'      => 'April 1, 2026',
        'author'    => 'Maria Petrova',
        'featured'  => false,
        'image'     => 'AF',
    ),
);
?>

<section class="pm-section pm-news-page">
    <div class="pm-container">

        <div class="pm-section-header">
            <span class="pm-section-tag" data-i18n="news.tag"><?php esc_html_e( 'News & Updates', 'playmarket' ); ?></span>
            <h1 class="pm-section-title" data-i18n="news.title"><?php esc_html_e( 'PlayMarket Newsroom', 'playmarket' ); ?></h1>
            <p class="pm-section-desc" data-i18n="news.desc"><?php esc_html_e( 'Stay informed with the latest platform updates, security announcements, and gaming market trends.', 'playmarket' ); ?></p>
        </div>

        <?php
        $featured = null;
        foreach ( $articles as $a ) {
            if ( ! empty( $a['featured'] ) ) {
                $featured = $a;
                break;
            }
        }
        if ( $featured ) :
        ?>
        <a href="#" class="pm-news-featured">
            <div class="pm-news-featured-image">
                <span class="pm-news-featured-initials"><?php echo esc_html( $featured['image'] ); ?></span>
            </div>
            <div class="pm-news-featured-body">
                <span class="pm-badge pm-badge-escrow"><?php echo esc_html( $featured['category'] ); ?></span>
                <h2 class="pm-news-featured-title"><?php echo esc_html( $featured['title'] ); ?></h2>
                <p class="pm-news-featured-excerpt"><?php echo esc_html( $featured['excerpt'] ); ?></p>
                <div class="pm-news-meta">
                    <span class="pm-news-meta-author"><?php echo esc_html( $featured['author'] ); ?></span>
                    <span class="pm-news-meta-date"><?php echo esc_html( $featured['date'] ); ?></span>
                </div>
            </div>
        </a>
        <?php endif; ?>

        <div class="pm-news-grid">
            <?php $ni = 0; foreach ( $articles as $article ) : ?>
                <?php if ( ! empty( $article['featured'] ) ) { continue; } $ni++; ?>
                <a href="#" class="pm-news-card pm-animate-once pm-fade-in-up pm-delay-<?php echo min( $ni, 8 ); ?>">
                    <div class="pm-news-card-image">
                        <span class="pm-news-card-initials"><?php echo esc_html( $article['image'] ); ?></span>
                    </div>
                    <div class="pm-news-card-body">
                        <span class="pm-news-card-category" style="
                            <?php
                            $cat_colors = array(
                                'Security' => '--pm-neon',
                                'Updates'  => '--pm-info',
                                'Games'    => '--pm-warning',
                                'Community' => 'var(--pm-text-secondary)',
                                'Trading'  => '--pm-neon-bright',
                                'Events'   => '--pm-danger',
                            );
                            $color = isset( $cat_colors[ $article['category'] ] ) ? $cat_colors[ $article['category'] ] : 'var(--pm-text-secondary)';
                            echo 'color: var(' . esc_attr( $color ) . ');';
                            ?>
                        "><?php echo esc_html( $article['category'] ); ?></span>
                        <h3 class="pm-news-card-title"><?php echo esc_html( $article['title'] ); ?></h3>
                        <p class="pm-news-card-excerpt"><?php echo esc_html( $article['excerpt'] ); ?></p>
                        <div class="pm-news-meta">
                            <span class="pm-news-meta-date"><?php echo esc_html( $article['date'] ); ?></span>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>

        <div class="pm-market-pagination">
            <button class="pm-btn pm-btn-secondary pm-btn-sm" disabled>&larr; <span data-i18n="news.prev"><?php esc_html_e( 'Previous', 'playmarket' ); ?></span></button>
            <div class="pm-market-pages">
                <span class="pm-market-page active">1</span>
                <span class="pm-market-page">2</span>
                <span class="pm-market-page">3</span>
            </div>
            <button class="pm-btn pm-btn-secondary pm-btn-sm"><span data-i18n="news.next"><?php esc_html_e( 'Next', 'playmarket' ); ?></span> &rarr;</button>
        </div>

    </div>
</section>

<?php
get_footer();
