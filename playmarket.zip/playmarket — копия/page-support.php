<?php
/**
 * Template Name: Support
 *
 * @package PlayMarket
 * @since 1.0.0
 */

get_header();

$admin_team = array(
    array(
        'name'        => 'Alexei Volkov',
        'role'        => 'Head Administrator',
        'description' => 'Oversees all platform operations, escrow policy development, and strategic growth initiatives. Final authority on complex dispute escalations.',
        'initials'    => 'AV',
        'status'      => 'online',
    ),
    array(
        'name'        => 'Maria Petrova',
        'role'        => 'Community Manager',
        'description' => 'Manages community communications, user feedback integration, and public announcements. First point of contact for platform-wide issues.',
        'initials'    => 'MP',
        'status'      => 'online',
    ),
    array(
        'name'        => 'Dmitri Kozlov',
        'role'        => 'Lead Developer',
        'description' => 'Responsible for platform architecture, security infrastructure, and the escrow smart-contract system. Handles technical incident response.',
        'initials'    => 'DK',
        'status'      => 'online',
    ),
    array(
        'name'        => 'Yuki Tanaka',
        'role'        => 'Head of Moderation',
        'description' => 'Leads the global moderation team, enforces platform guidelines, and oversees seller verification and quality assurance programs.',
        'initials'    => 'YT',
        'status'      => 'offline',
    ),
);

$mod_team = array(
    array(
        'name'        => 'Rustam Yegenov',
        'role'        => 'Senior Arbiter',
        'description' => 'Specializes in high-value escrow dispute resolution. Certified mediator with over 2,000 resolved cases and a 98.7% satisfaction rate.',
        'initials'    => 'RY',
        'status'      => 'online',
    ),
    array(
        'name'        => 'Aigerim Zhanat',
        'role'        => 'Senior Arbiter',
        'description' => 'Expert in P2P trading disputes with focus on account recovery and digital asset verification. Fluent in Kazakh, Russian, and English.',
        'initials'    => 'AZ',
        'status'      => 'online',
    ),
    array(
        'name'        => 'Sergei Makarov',
        'role'        => 'Moderator',
        'description' => 'Reviews reported listings, enforces platform rules, and handles first-response dispute triage. Active in the CS2 and Valorant trading communities.',
        'initials'    => 'SM',
        'status'      => 'online',
    ),
    array(
        'name'        => 'Aidana Nurlan',
        'role'        => 'Moderator',
        'description' => 'Focuses on mobile gaming marketplace moderation including Mobile Legends, PUBG Mobile, and Genshin Impact listings and dispute resolution.',
        'initials'    => 'AN',
        'status'      => 'online',
    ),
    array(
        'name'        => 'Vladimir Sorokin',
        'role'        => 'Junior Arbiter',
        'description' => 'Handles low-to-medium value escrow disputes under senior supervision. Rapidly building expertise in arbitration procedures and evidence analysis.',
        'initials'    => 'VS',
        'status'      => 'offline',
    ),
    array(
        'name'        => 'Dana Sarsenova',
        'role'        => 'Junior Moderator',
        'description' => 'Assists with listing verification, user support tickets, and first-level dispute intake. Supports the Kazakh-speaking user base.',
        'initials'    => 'DS',
        'status'      => 'online',
    ),
);

$support_stats = array(
    array( 'number' => '4,200+', 'label' => 'Disputes Resolved' ),
    array( 'number' => '48h',    'label' => 'Avg. Resolution Time' ),
    array( 'number' => '96.3%',  'label' => 'Satisfaction Rate' ),
    array( 'number' => '14',     'label' => 'Team Members' ),
);
?>

<section class="pm-section pm-support-page">
    <div class="pm-container">

        <div class="pm-section-header">
            <span class="pm-section-tag" data-i18n="support.tag"><?php esc_html_e( 'Support & Moderation', 'playmarket' ); ?></span>
            <h1 class="pm-section-title" data-i18n="support.title"><?php esc_html_e( 'Meet the Team', 'playmarket' ); ?></h1>
            <p class="pm-section-desc" data-i18n="support.desc"><?php esc_html_e( 'Our dedicated administration and moderation team works around the clock to ensure safe, fair trading for every PlayMarket user.', 'playmarket' ); ?></p>
        </div>

        <div class="pm-support-stats">
            <?php foreach ( $support_stats as $stat ) : ?>
            <div class="pm-support-stat">
                <span class="pm-support-stat-number"><?php echo esc_html( $stat['number'] ); ?></span>
                <span class="pm-support-stat-label"><?php echo esc_html( $stat['label'] ); ?></span>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="pm-support-section">
            <div class="pm-support-section-header">
                <h2 class="pm-support-heading">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                    <span data-i18n="support.admin_heading"><?php esc_html_e( 'Administration', 'playmarket' ); ?></span>
                </h2>
                <p class="pm-support-section-desc" data-i18n="support.admin_desc"><?php esc_html_e( 'The leadership team responsible for platform strategy, policy, and overall community well-being.', 'playmarket' ); ?></p>
            </div>
            <div class="pm-team-grid">
                <?php $ai = 0; foreach ( $admin_team as $member ) : $ai++; ?>
                <div class="pm-team-card pm-animate-once pm-fade-in-up pm-delay-<?php echo $ai; ?>">
                    <div class="pm-team-avatar">
                        <img class="pm-team-avatar-img" src="https://ui-avatars.com/api/?name=<?php echo urlencode( $member['name'] ); ?>&background=00FF00&color=000000&size=128" alt="<?php echo esc_attr( $member['name'] ); ?>" width="72" height="72">
                        <span class="pm-team-status pm-status-<?php echo esc_attr( $member['status'] ); ?>"></span>
                    </div>
                    <h3 class="pm-team-name"><?php echo esc_html( $member['name'] ); ?></h3>
                    <span class="pm-team-role"><?php echo esc_html( $member['role'] ); ?></span>
                    <p class="pm-team-desc"><?php echo esc_html( $member['description'] ); ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="pm-support-section">
            <div class="pm-support-section-header">
                <h2 class="pm-support-heading">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    <span data-i18n="support.mod_heading"><?php esc_html_e( 'Moderation & Arbitration', 'playmarket' ); ?></span>
                </h2>
                <p class="pm-support-section-desc" data-i18n="support.mod_desc"><?php esc_html_e( 'Our trained moderators and arbiters handle disputes, enforce rules, and ensure every transaction is fair. They monitor platform operations 24/7 and are empowered to resolve issues under the 3-Hour Dispute Rule.', 'playmarket' ); ?></p>
            </div>
            <div class="pm-team-grid">
                <?php $mi = 0; foreach ( $mod_team as $member ) : $mi++; ?>
                <div class="pm-team-card pm-animate-once pm-fade-in-up pm-delay-<?php echo $mi; ?>">
                    <div class="pm-team-avatar">
                        <img class="pm-team-avatar-img" src="https://ui-avatars.com/api/?name=<?php echo urlencode( $member['name'] ); ?>&background=00FF00&color=000000&size=128" alt="<?php echo esc_attr( $member['name'] ); ?>" width="72" height="72">
                        <span class="pm-team-status pm-status-<?php echo esc_attr( $member['status'] ); ?>"></span>
                    </div>
                    <h3 class="pm-team-name"><?php echo esc_html( $member['name'] ); ?></h3>
                    <span class="pm-team-role"><?php echo esc_html( $member['role'] ); ?></span>
                    <p class="pm-team-desc"><?php echo esc_html( $member['description'] ); ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="pm-support-cta">
            <div class="pm-support-cta-content">
                <h2 data-i18n="support.cta_title"><?php esc_html_e( 'Need Help?', 'playmarket' ); ?></h2>
                <p data-i18n="support.cta_text"><?php esc_html_e( 'If you have an active dispute or need immediate assistance, open a support ticket and our team will respond within 2 hours.', 'playmarket' ); ?></p>
                <a href="#" class="pm-btn pm-btn-primary pm-btn-lg" data-i18n="support.ticket_btn"><?php esc_html_e( 'Open Support Ticket', 'playmarket' ); ?></a>
            </div>
        </div>

    </div>
</section>

<?php
get_footer();
